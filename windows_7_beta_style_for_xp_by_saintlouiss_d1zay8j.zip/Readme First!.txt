As requested..
Hi.. after posting a screenshots a few days ago I decided to release this visual style.

This VS is for Windows XP!!!
Color schemes available:
Twilight (Default), Graphite, Leaf, Ruby, Slate, Lavender, Sky, Frost, Chocolate, Taupe.

Choose your own wallpaper to match those colors.

Notes:
- You must install LSPatch (created by WindowsX) first to remove logoff/turn off computer text. Use Google to find it.
- Set your quicklaunch icons view to Large Icons.
- You may use Transbar or StartBarFader to make your taskbar transparent.


CREDITS:
- Vishal Gupta for his core work VistaVG



