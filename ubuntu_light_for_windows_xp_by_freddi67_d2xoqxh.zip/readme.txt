Many thanks for downloading the 

     Ubuntu Light Theme
          for Windows XP !


This port to Windows as well as the original Light themes for Linux are under a Creative Commons License, that means you can feel free to share, redistribute and (please) edit!

My intention was to bring the new polished look of Ubuntu and a more consistent visual appearance into my windows programs in Wine or Virtual Box. As XP is still more widely used than Windows7 (especially in VirtualBox), I started with the Ambiance color scheme in XP msstyles format. Contributions of any kind are highly welcome!

This is a work in progress and there are still some bugs. If you have more knowledge of Windows Visual Styles, it would be great if you could help me:
- I couldn't get the progress bar to work
- in general Windows uses smaller sizes of fonts and controls
- some font colors still do not match
- problems with the dark menu background (some apps override it and display both text and background white)
- an icon theme would be awesome, aswell as Radiance and Ambiance Dark color scheme
