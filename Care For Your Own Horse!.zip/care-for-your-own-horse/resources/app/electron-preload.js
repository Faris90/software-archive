'use strict';
const {contextBridge, ipcRenderer} = require('electron');
