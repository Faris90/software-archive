ATTENTION
FOR COMMON/POSSIBLE ERRORS PLEASE CONSULT COMMON_ERRORS.TXT
-------------------------------------------------------------------------------------------------
SUDO MUST BE PRESENT & YOUR USER ACCOUNT MUST BE PRESENT IN THE SUDOERS FILE! (or in other words be able to run root commands using sudo)
-------------------------------------------------------------------------------------------------
IT IS NOT RECOMMENDED TO INSTALL WITHOUT A DESKTOP ENVIRONMENT ALREADY PRESENT. YOU SHOULD TEMPORARILY INSTALL SOMETHING LIGHTWEIGHT LIKE XFCE, INSTALL ICE2K USING THE SCRIPT AND THEN UNINSTALL THE TEMPORARY DE

Open up a terminal in this directory and run: chmod +x install.sh
Run install.sh
Get imagemagick 6

Get Wine Tahoma font installer
https://gist.githubusercontent.com/maxwelleite/ee5a1a4222dd43c8b4af5c99ed72b3fc/raw/47f6627b6dbba7114906e6b5cf970647af74b591/ttf-wine-tahoma-installer.sh

Get IBM VGA font for terminal
https://int10h.org/oldschool-pc-fonts/fontlist/font?ibm_vga_8x16
There should be a [DOWNLOAD] button at the top. Press it and select 
oldschool_pc_­font_pack_vX.X­_linux.zip

Unzip the archive in a seperate folder, open the 'ttf - Ac' folder and run
sudo cp *.ttf /usr/share/fonts/truetype/  or wherever your fonts are located



Also
MAKE SURE YOU DO NOT RUN ICE2K.SYS USING "ICEWM SESSION"
Use the .Xsession file.
On some display managers this option is called "Default"

All code I have made is licensed under GPLv2

Credits to enfaun and PixelOCDGuy for IceWM theme
Credits to enfaun for GTK3 theme
Credits to ohno for helping a bit out with my code
Credits to zippy for testing
Credits to myself (/usr/bin/tflush) for creating the project and making
most stuff in it
Credits to nestoris for SE98

If I forgot to credit someone, let me know.
