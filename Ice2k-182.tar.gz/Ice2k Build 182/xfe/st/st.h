/* Guard C code in headers, while including them from C++ */
#ifdef  __cplusplus
extern "C" {
#endif

int st(int argc, char **argv);

#ifdef  __cplusplus
}
#endif
