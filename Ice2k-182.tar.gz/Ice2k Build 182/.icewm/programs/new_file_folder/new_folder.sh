#!/usr/bin/env wish

# 2024/05/08 - Made by m1nuscle_ 
# https://m1nuscle.neocities.org/
# All code here is licensed under LGPLv2.
# LGPLv2 license is in the LICENSE file.

# set title
wm title . {New folder}

# set window icon
image create photo icon -file [file dirname [file normalize [info script] ] ]/program.png
wm iconphoto . icon

# set window on top
wm attributes . -topmost no -type dialog

# disable resizing
wm resizable . 0 0

# center window and set size
set x_1 [expr {([winfo vrootwidth .] - 330) / 2}]
set y_1 [expr {([winfo vrootheight .] - 142) / 2}]
wm geometry . 330x142+$x_1+$y_1

#create image
image create photo folder -file [file dirname [file normalize [info script] ] ]/new_folder.png

#create canvases
canvas .main -width 330 -height 163 -highlightthickness 0
.main create image 24 21 -image folder -anchor nw

#create the area into which one enters the folder/file name
entry .main.folder_name -background white

#add the instruction text
.main create text 65 36 -anchor nw -font {Tahoma 8} -justify left -text {Create new folder:}

#add the two buttons
.main create window 149 111 -anchor nw -window [button .cancel -text {Cancel} -font {Tahoma 8} -command {cancel} -width 8]
.main create window 230 111 -anchor nw -window [button .accept -text {OK} -font {Tahoma 8} -command {createFolder} -width 8]

#make the program actually do something asynchronously
proc createFolder {} {
    global folder_name
    set folder_name [.main.folder_name get]
    if {$folder_name ne ""} {
        set cmd [list mkdir [file join $::env(HOME) Desktop $folder_name]]
        set pipe [open "|$cmd" r]
        fileevent $pipe readable [list handleOutput $pipe]
    } else {
        tk_messageBox -message "Cannot create a folder without a name :(" -icon warning -title "Error"
    }
}

proc handleOutput {pipe} {
    if {[eof $pipe]} {
        close $pipe
        exec xfe [file join $::env(HOME) Desktop]
        hideWindow
    } else {
        gets $pipe line
        puts $line
    }
}

proc hideWindow {} {
    wm withdraw .
}

proc cancel {} {
    exit
}

#pack that stuff
.main create window 65 60 -window .main.folder_name -anchor nw -width 250 -height 20
pack .main -side top -anchor nw
