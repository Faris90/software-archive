#!/usr/bin/env wish

# 2024/05/08 - Made by m1nuscle_ 
# https://m1nuscle.neocities.org/
# All code here is licensed under LGPLv2.
# LGPLv2 license is in the LICENSE file.


# set title
wm title . {New file}

# set window icon
image create photo icon -file [file dirname [file normalize [info script] ] ]/program.png
wm iconphoto . icon

# set window on top
wm attributes . -topmost no -type dialog

# disable resizing
wm resizable . 0 0

# center window and set size
set x_1 [ expr {([ winfo vrootwidth  . ] - 330 ) / 2 }]
set y_1 [ expr {([ winfo vrootheight . ] - 142 ) / 2 }]
wm geometry . 330x142+$x_1+$y_1

#create image
image create photo file -file [file dirname [file normalize [info script] ] ]/new_file.png

#create canvases
canvas .main -width 330 -height 163 -highlightthickness 0
.main create image 24 21 -image file -anchor nw

#create the area into which one enters the folder/file name
entry .main.file_name -background white
#pack .file_name -side top

#add the instruction text
.main create text 65 36 -anchor nw -font {Tahoma 8} -justify left -text {Create new file:}

#.button create window 129 12 -anchor nw -window [button .back -text $back_btn_text -font {Tahoma 8} -command {buttonClicked} -width 8]
#add the two buttons
.main create window 149 111 -anchor nw -window [button .cancel -text {Cancel} -font {Tahoma 8} -command {cancel} -width 8]
.main create window 230 111 -anchor nw -window [button .accept -text {OK} -font {Tahoma 8} -command {createFile} -width 8]

#make the progam actually do something
proc createFile {} {
    global file_name
    set file_name [.main.file_name get]
    if {$file_name ne ""} {
        set file_path $::env(HOME)/Desktop/$file_name
        exec touch $file_path
        exec xfe $::env(HOME)/Desktop/
        cancel
    } else {
        tk_messageBox -message "Cannot create a file without a name" -icon warning -title "Error"
    }
}


proc cancel {} {
    set proc_pid [pid]
    exec kill $proc_pid
}

#pack that stuff
.main create window 65 60 -window .main.file_name -anchor nw -width 250 -height 20
pack .main -side top -anchor nw
