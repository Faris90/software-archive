#!/bin/bash

#-----------------------------------------------------#
# 2024/06/20 - created install.sh - m1nuscle
#This script serves as an automated installer
#for Ice2k.sys. This is the second revision, a
#fter some testing revealed the flaws of the 
#first one                                                 
#
#This script is licensed under the GPLv3 Lice
#nse. Credits to me for creating this script a
#nd zimmer for helping with testing and fin 
#ding bugs                                              
#---------------------------------------------------#


#-----------------------------------------------------#
# Define necessary functions
#-----------------------------------------------------#

# Function to install packages
install_package() {
  local package=$1
  echo "Installing $package..."
  sudo apt-get install -y "$package"
  if [ $? -ne 0 ] 
  then
    echo "Failed to install $package. Exiting script."
    #exit 1
  fi
}

# Function for cloning repos (used for yad & SE98)
clone_repo() {
  local repo_url=$1
  local branch=$2
  local dest_dir=$3
  local max_retries=5
  local attempt=1

  # Ensure the destination directory is empty
  if [ -d "$dest_dir" ]
   then
    echo "Destination directory $dest_dir already exists or has to be created"
    read -p "Do you want to clear its contents and/or create it? (Y/N): " response

    case "$response" in
      [Yy]* ) 
        echo "Clearing contents of $dest_dir..."
        rm -rf "$dest_dir"
        mkdir -p "$dest_dir"
        ;;
      [Nn]* ) 
        echo "Aborting script as per user request."
        exit 1
        ;;
      * ) 
        echo "Invalid response. Aborting script."
        exit 1
        ;;
    esac

  else
    mkdir -p "$dest_dir"
  fi

  while [ $attempt -le $max_retries ]
   do
    echo "Attempting to clone repository branch $branch (Attempt $attempt/$max_retries)..."
    git clone -b "$branch" "$repo_url" "$dest_dir"

    if [ $? -eq 0 ]
     then
      echo "Repository cloned successfully."
      return 0
    else
      echo "Failed to clone repository. Retrying in 5 seconds..."
      sleep 5
    fi

    attempt=$((attempt + 1))
  done

  echo "Failed to clone repository after $max_retries attempts."
  echo "Please restart the script"
  rm -rf "$dest_dir"
  exit 1
}


# Function for moving all files located in the install directory to home
copy_to_home() {
  local item=$1
  echo "Copying $item to $HOME..."
  cp -r "$item" "$HOME"
  sleep 0.3
  if [ $? -ne 0 ]
   then
    echo "Failed to copy $item to $HOME. Please copy manually"
    rm -r $item
  fi
}

check_sudoers() {
  sudo -l > /dev/null 2>&1
  if [ $? -ne 0 ]; then
    echo "The user $(whoami) is not in the sudoers file. Exiting script."
    exit 1
  else
    echo "The user $(whoami) is in the sudoers file."
  fi
}
#Define some important things
packages_to_install=(
  "git"
  "build-essential"
  "libx11-dev"
  "intltool"
  "libxcb-util-dev"
  "libfox-1.6-dev"
  "libx11-xcb-dev"
  "autoconf"
  "automake"
  "intltool"
  "libgtk2.0-dev"
  "libgtk-3-dev"
  "autoconf-archive"

  "gtk2-engines"
  "dunst"
  "idesk"
  "icewm"
  "parcellite"
  "feh"
  "lxappearance"
  "arandr"
  "xscreensaver"
  "tktray"
  "tcl"
  "tk"
  "vlc"

)

items_to_copy=(
  ".config"
  ".icewm"
  ".idesktop"
  ".themes"
  ".gtkrc-2.0"
  ".ideskrc"
  ".xinitrc"
  ".Xsession"  
  )
#Run some last checks before installing

# Check if xfe directory exists
if [ ! -d "xfe" ] 
then
  echo "Terminating script - The directory 'xfe' does not exist - did you move the install script?"
  exit 1
fi


# Check if ~/.icons directory exists
ICONS_DIR="$HOME/.icons"
if [ ! -d "$ICONS_DIR" ] 
then
  echo "The directory '$ICONS_DIR' does not exist. Creating /.icons in $HOME"
  mkdir $HOME/.icons
fi

#Check if script is running as root
if [ "$EUID" -ne 0 ]
then
  echo "This script is not running as root as per requirement - this is good"
else
  echo "ERROR! Run script without root and try again"
fi

#Check if the user is in the sudoers file
check_sudoers

#---------------------------------------------------#
# Actually start installing
#---------------------------------------------------#

#Copy all items to $HOME
for item in "${items_to_copy[@]}" 
do
  copy_to_home $item
done
echo "All items copied successfully."

#Install all needed packages
for package in "${packages_to_install[@]}" 
do
  install_package $package
done
echo "All packages installed successfully."

#Clone the SE98 repository
REPO_URL="https://github.com/nestoris/Win98SE"
BRANCH="main"
mkdir $HOME/Win98SE
DEST_DIR="$HOME/Win98SE"

clone_repo "$REPO_URL" "$BRANCH" "$DEST_DIR"

#Copy everything over to /.icons
echo "Copying icons to $HOME/.icons"
cp -r $HOME/Win98SE/SE98 $HOME/.icons
cp -r .cursors/Chicago95\ Standard\ Cursors $HOME/.icons
chmod +x $HOME/.icons/SE98/win2k_icons.awk
$HOME/.icons/SE98/./win2k_icons.awk

#Compile xfe
cd xfe
echo "Compiling xfe - 1. running ./configure"
./configure
if [ $? -ne 0 ] 
then
  echo "./configure failed. Exiting script."
  exit 1
fi

echo "Compiling xfe - 2. running make"
sudo make
if [ $? -ne 0 ] 
then
  echo "make failed. Exiting script."
  exit 1
fi

echo "Compiling xfe - 3. running make install"
sudo make install
if [ $? -ne 0 ] 
then
  echo "make install failed. Exiting script."
  exit 1
fi
cd ..
#Cloning and compiling yad
REPO_URL="https://github.com/step-/yad.git"
BRANCH="maintain-gtk2"
mkdir $HOME/maintain-gtk2
DEST_DIR="$HOME/maintain-gtk2"

clone_repo "$REPO_URL" "$BRANCH" "$DEST_DIR"

#Configure everything
cd $HOME/maintain-gtk2
autoreconf -ivf
intltoolize --force

#Compiling yad
echo "Compiling yad - 1. running ./configure"
./configure
if [ $? -ne 0 ] 
then
  echo "./configure failed. Exiting script."
  exit 1
fi

echo "Compiling yad - 2. running make"
sudo make
if [ $? -ne 0 ] 
then
  echo "make failed. Exiting script."
  exit 1
fi

echo "Compiling yad - 3. running make install"
sudo make install
if [ $? -ne 0 ] 
then
  echo "make install failed. Exiting script."
  exit 1
fi

#Final message (we done now, woohoo)
echo "ATTENTION"
echo "Ice2k.sys was successfully installed"
echo "ATTENTION"
echo "Check README for further instructions"
